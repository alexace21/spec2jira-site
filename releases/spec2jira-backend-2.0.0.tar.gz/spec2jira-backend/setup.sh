#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════
# Spec2JIRA — Model Setup
# Downloads base AI models from Hugging Face.
# Run once before first 'docker compose up'.
#
# Requirements: ~20GB disk, ~20min on fast connection
# ══════════════════════════════════════════════════════════════
set -euo pipefail

python3 -m pip

MODELS_DIR="./models"
BASE_DIR="${MODELS_DIR}/base"
FINETUNED_DIR="${MODELS_DIR}/finetuned"

echo "══════════════════════════════════════════════"
echo "  Spec2JIRA — Model Setup"
echo "══════════════════════════════════════════════"
echo ""

# ── Check prerequisites ──
if ! command -v python3 &> /dev/null; then
    echo "❌ python3 is required. Install it first."
    exit 1
fi

# Install huggingface_hub if not present
python3 -c "import huggingface_hub" 2>/dev/null || {
    echo "📦 Installing huggingface_hub..."
    pip install --quiet huggingface_hub
}

# ── Create directories ──
mkdir -p "${BASE_DIR}" "${FINETUNED_DIR}"

# ── Download 14B GGUF (base model for extraction — Phase 0/1) ──
echo ""
echo "📥 [1/2] Downloading Qwen2.5-14B-Instruct GGUF (~9GB)..."
echo "         Used for: spec extraction and classification"
echo ""
python3 -c "
from huggingface_hub import hf_hub_download
hf_hub_download(
    repo_id='bartowski/Qwen2.5-14B-Instruct-GGUF',
    filename='Qwen2.5-14B-Instruct-Q4_K_M.gguf',
    local_dir='${BASE_DIR}/Qwen2.5-14B-Instruct-GGUF',
    local_dir_use_symlinks=False,
)
print('✅ 14B GGUF model downloaded.')
"

# ── Download 7B base (for Phase 2 — story generation) ──
echo ""
echo "📥 [2/2] Downloading Qwen2.5-7B-Instruct (~15GB)..."
echo "         Used for: story generation (or as base for fine-tuning)"
echo ""
python3 -c "
from huggingface_hub import snapshot_download
snapshot_download(
    repo_id='Qwen/Qwen2.5-7B-Instruct',
    local_dir='${BASE_DIR}/Qwen2.5-7B-Instruct',
    local_dir_use_symlinks=False,
)
print('✅ 7B base model downloaded.')
"

echo ""
echo "══════════════════════════════════════════════"
echo "  ✅ Setup complete!"
echo ""
echo "  Models downloaded to: ${MODELS_DIR}/"
echo ""
echo "  Next steps:"
echo "    1. cp .env.example .env"
echo "    2. Edit .env with your Atlassian credentials"
echo "    3. docker compose up -d"
echo ""
echo "  To fine-tune later:"
echo "    1. Add training data to training/data/"
echo "    2. Run: ./train.sh"
echo "══════════════════════════════════════════════"
