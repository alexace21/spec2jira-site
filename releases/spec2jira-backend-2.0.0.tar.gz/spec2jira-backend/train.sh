#!/usr/bin/env bash
# ══════════════════════════════════════════════════════════════
# Spec2JIRA — Fine-Tune Model
# Full pipeline: prepare data → LoRA training → merge → ready
#
# Prerequisites:
#   - Docker running: docker compose up -d
#   - Base models downloaded: ./setup.sh
#   - Training data in training/data/
#
# Duration: ~10-15 minutes on L4/A10 GPU
# ══════════════════════════════════════════════════════════════
# Install training-specific dependencies
pip install --no-cache-dir -r requirements-train.txt

set -euo pipefail

TRAINING_DIR="./training/data"
FINETUNED_DIR="./models/finetuned/qwen2.5-7b-spec2jira"
BASE_MODEL_7B="./models/base/Qwen2.5-7B-Instruct"

# Paths inside Docker container
CONTAINER_TRAINING="/training/data"
CONTAINER_OUTPUT="/training/output"
CONTAINER_FINETUNED="/models/finetuned/qwen2.5-7b-spec2jira"
CONTAINER_BASE_7B="/models/base/Qwen2.5-7B-Instruct"

echo "══════════════════════════════════════════════"
echo "  Spec2JIRA — Fine-Tuning Pipeline"
echo "══════════════════════════════════════════════"
echo ""

# ── Preflight checks ──

# 1. Docker running?
if ! docker compose ps --status running | grep -q spec2jira; then
    echo "❌ Spec2JIRA container is not running."
    echo "   Start it first: docker compose up -d"
    exit 1
fi

# 2. Training data exists?
if [ ! -d "${TRAINING_DIR}" ] || [ -z "$(ls -A ${TRAINING_DIR} 2>/dev/null)" ]; then
    echo "❌ No training data found in ${TRAINING_DIR}/"
    echo ""
    echo "   Add training pairs — each pair is a folder:"
    echo "     training/data/pair_001/input.md    ← Confluence spec"
    echo "     training/data/pair_001/output.json ← Expected JIRA breakdown"
    echo ""
    echo "   See training/README.md for format details."
    exit 1
fi

# 3. Base model exists?
if [ ! -d "${BASE_MODEL_7B}" ]; then
    echo "❌ Base model not found at ${BASE_MODEL_7B}"
    echo "   Run ./setup.sh first."
    exit 1
fi

# ── Count data ──
PAIR_COUNT=$(find "${TRAINING_DIR}" -mindepth 1 -maxdepth 1 -type d 2>/dev/null | wc -l)
JSONL_COUNT=$(find "${TRAINING_DIR}" -maxdepth 1 -name "*.jsonl" 2>/dev/null | wc -l)

echo "📊 Training data:"
if [ "${PAIR_COUNT}" -gt 0 ]; then
    echo "   ${PAIR_COUNT} pair folders found"
fi
if [ "${JSONL_COUNT}" -gt 0 ]; then
    echo "   ${JSONL_COUNT} JSONL files found"
fi

TOTAL=$((PAIR_COUNT + JSONL_COUNT))
if [ "${TOTAL}" -lt 5 ]; then
    echo ""
    echo "⚠️  Warning: Very few training examples. Recommend ≥20 for good results."
    read -p "   Continue anyway? (y/N) " -n 1 -r
    echo ""
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then exit 1; fi
fi

echo ""
echo "═══ Step 1/3: Preparing data ═══"
docker compose exec spec2jira python3 -m app.training.prepare_data \
    --data-dir "${CONTAINER_TRAINING}"

echo ""
echo "═══ Step 2/3: LoRA fine-tuning ═══"
echo "   This takes ~10-15 minutes on L4 GPU..."
echo ""
docker compose exec \
    -e TRAINING_DATA_DIR="${CONTAINER_TRAINING}" \
    -e TRAINING_OUTPUT_DIR="${CONTAINER_OUTPUT}" \
    -e BASE_MODEL_7B_PATH="${CONTAINER_BASE_7B}" \
    spec2jira python3 -m app.training.train_qwen

echo ""
echo "═══ Step 3/3: Merging adapter ═══"

# Find the latest adapter directory
ADAPTER_DIR=$(docker compose exec spec2jira \
    find "${CONTAINER_OUTPUT}" -maxdepth 1 -type d -name "spec2jira-qwen7b-*" \
    | sort | tail -1 | tr -d '\r')

if [ -z "${ADAPTER_DIR}" ]; then
    echo "❌ No adapter found in ${CONTAINER_OUTPUT}"
    exit 1
fi

echo "   Adapter: ${ADAPTER_DIR}"
echo "   Merging into standalone model..."

docker compose exec spec2jira python3 -m app.training.merge_adapter \
    --adapter-dir "${ADAPTER_DIR}" \
    --base-model "${CONTAINER_BASE_7B}" \
    --output-dir "${CONTAINER_FINETUNED}"

echo ""
echo "══════════════════════════════════════════════"
echo "  ✅ Fine-tuning complete!"
echo "══════════════════════════════════════════════"
echo ""
echo "  Model saved to: models/finetuned/qwen2.5-7b-spec2jira/"
echo ""
echo "  To activate:"
echo "    1. Edit .env → PIPELINE_MODE=finetuned"
echo "    2. docker compose restart"
echo ""
echo "  That's it — next generation will use your fine-tuned model."
echo "══════════════════════════════════════════════"
