# Spec2JIRA Backend — Installation Guide

## What This Is

The Spec2JIRA backend runs AI models that convert your Confluence specifications
into structured Jira work items. It runs on **your infrastructure** — your data
never leaves your network.

## Requirements

| Component   | Requirement                                                        |
|-------------|--------------------------------------------------------------------|
| **OS**      | Ubuntu 22.04 LTS (other Linux distros may work but are untested)   |
| **GPU**     | NVIDIA with ≥24GB VRAM — tested: L4, A10, A100, RTX 4090          |
| **RAM**     | 32GB system RAM (16GB minimum, 32GB recommended)                   |
| **Disk**    | 100GB free space (10GB image + 25GB models + Docker build overhead) |
| **Drivers** | NVIDIA driver 550+                                                 |
| **Software**| Docker 24+, Docker Compose v2, NVIDIA Container Toolkit            |
| **Network** | Static IP or domain with HTTPS, reachable from Atlassian Cloud     |

## Step 0: NVIDIA Drivers

Skip this step if `nvidia-smi` already shows your GPU.

```bash
# Install NVIDIA drivers
sudo apt update
sudo apt install -y nvidia-driver-550

# Reboot required after driver install
sudo reboot

# After reboot, verify
nvidia-smi
# Should show your GPU model and driver version
```

## Step 1: Docker + NVIDIA Container Toolkit

Skip any part you already have installed.

```bash
# ── Install Docker ──
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker $USER
# Log out and back in for group change to take effect

# ── Install NVIDIA Container Toolkit ──
curl -fsSL https://nvidia.github.io/libnvidia-container/gpgkey | \
  sudo gpg --dearmor -o /usr/share/keyrings/nvidia-container-toolkit-keyring.gpg
curl -s -L https://nvidia.github.io/libnvidia-container/stable/deb/nvidia-container-toolkit.list | \
  sed 's#deb https://#deb [signed-by=/usr/share/keyrings/nvidia-container-toolkit-keyring.gpg] https://#g' | \
  sudo tee /etc/apt/sources.list.d/nvidia-container-toolkit.list

sudo apt-get update
sudo apt-get install -y nvidia-container-toolkit
sudo nvidia-ctk runtime configure --runtime=docker
sudo systemctl restart docker

# ── Verify GPU access in Docker ──
docker run --rm --gpus all nvidia/cuda:12.8.0-base-ubuntu22.04 nvidia-smi
# Should show the same GPU as bare-metal nvidia-smi
```

## Step 2: Download Spec2JIRA

```bash
# Download and extract the setup package
curl -fsSL https://spec2jira.com/releases/spec2jira-backend-2.0.0.tar.gz | tar xz
cd spec2jira-backend
```

This gives you:

| File                     | Purpose                                    |
|--------------------------|--------------------------------------------|
| `docker-compose.yml`    | Container configuration (pulls from Docker Hub) |
| `setup.sh`              | Downloads AI models from Hugging Face      |
| `.env.example`          | Configuration template                     |
| `requirements-train.txt`| Dependencies for optional fine-tuning      |
| `INSTALL.md`            | This file                                  |

## Step 3: Download AI Models

The backend uses two open-source Qwen 2.5 models (~25GB total download).
This is a one-time step.

```bash
chmod +x setup.sh
./setup.sh
```

**What this downloads:**
- Qwen 2.5 14B Instruct (GGUF, ~9GB) — used for spec extraction and classification
- Qwen 2.5 7B Instruct (~15GB) — base for optional fine-tuning

**Requirements:** Python 3 and pip must be available on the host (for the
`huggingface_hub` download library). The models are saved to `./models/`
and mounted into the Docker container.

**Note:** If the download is interrupted, re-run `./setup.sh` — it will
resume where it left off.

## Step 4: Configure

```bash
cp .env.example .env
nano .env    # or your preferred editor
```

**Required settings:**

| Variable                          | Description                                | Example                                  |
|-----------------------------------|--------------------------------------------|------------------------------------------|
| `ATLASSIAN_SITE_URL`             | Your Atlassian site (without protocol)     | `yourcompany.atlassian.net`              |
| `ATLASSIAN_SERVICE_ACCOUNT_EMAIL`| Service account email                      | `spec2jira-svc@yourcompany.com`          |
| `ATLASSIAN_SERVICE_ACCOUNT_TOKEN`| API token for the service account          | `ATATT3xF...`                            |
| `JIRA_PROJECT_KEY`              | Default Jira project for created issues    | `PROJ`                                   |

**Creating a service account (recommended):**

1. Create a dedicated Atlassian account (e.g., `spec2jira-svc@yourcompany.com`)
2. Grant it **read access** to the Confluence spaces containing your specs
3. Grant it **write access** to the target Jira project
4. Generate an API token at https://id.atlassian.com/manage-profile/security/api-tokens
5. Use this email and token in `.env`

Using a dedicated service account with minimal permissions is a security
best practice — it limits the backend's access to only what it needs.

## Step 5: Start

```bash
docker compose up -d

# Wait ~60 seconds for models to load into GPU memory, then verify
curl http://localhost:8000/health
# → {"status": "ok", "message": "Spec2JIRA backend is healthy"}
```

**First startup** pulls the Docker image (~11GB) and loads AI models into
GPU memory. This can take 2-5 minutes. Subsequent starts are faster.

Watch startup progress:
```bash
docker compose logs -f
```

## Step 6: Expose via HTTPS

The backend must be reachable from Atlassian Cloud over HTTPS.

**nginx reverse proxy (recommended):**

```bash
# Install nginx and certbot
sudo apt install -y nginx certbot python3-certbot-nginx

# Get SSL certificate (replace with your domain)
sudo certbot --nginx -d ai.yourcompany.com
```

Add to your nginx site config (`/etc/nginx/sites-enabled/spec2jira`):

```nginx
server {
    listen 443 ssl;
    server_name ai.yourcompany.com;

    ssl_certificate     /etc/letsencrypt/live/ai.yourcompany.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/ai.yourcompany.com/privkey.pem;

    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;

    location / {
        proxy_pass http://localhost:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_read_timeout 1800s;  # Pipeline runs can take up to 25 minutes
    }
}
```

```bash
sudo nginx -t && sudo systemctl reload nginx

# Verify HTTPS works
curl https://ai.yourcompany.com/health
```

## Step 7: Connect the Forge App

1. Install **Spec2Tickets for Confluence and Jira** from the Atlassian Marketplace
2. In Confluence, open any page and look for the Spec2Tickets button in the toolbar
3. On first use, go to **Settings** (gear icon in the app panel)
4. Enter your backend URL (e.g., `https://ai.yourcompany.com`)
5. Click **Test Connection** — you should see a green checkmark
6. Enter your default Jira Project Key (e.g., `PROJ`)
7. Click **Save**

You're ready — open any Confluence specification page and click **Convert**.

## Commands Reference

| Command                                       | Description                    |
|-----------------------------------------------|--------------------------------|
| `docker compose up -d`                        | Start backend                  |
| `docker compose down`                         | Stop backend                   |
| `docker compose logs -f`                      | View live logs                 |
| `docker compose restart`                      | Restart after config change    |
| `docker compose pull && docker compose up -d` | Update to latest version       |

## Fine-Tuning (Optional)

Improve breakdown quality by training on your own specification data:

```bash
# 1. Install training dependencies (one-time, inside the container)
docker exec -it spec2jira-backend pip install -r /training/requirements-train.txt

# 2. Add training pairs to training/data/ (see training/README.md for format)

# 3. Run training (~10-15 minutes on L4)
docker exec -it spec2jira-backend python -m app.training.train_qwen

# 4. Update config to use fine-tuned model
# Edit .env: set PIPELINE_MODE=finetuned

# 5. Restart
docker compose restart
```

## Troubleshooting

**`nvidia-smi` works on host but `docker run --gpus all` fails**
→ NVIDIA Container Toolkit is not installed or Docker was not restarted.
Re-run the Container Toolkit install commands in Step 1.

**"No space left on device" during Docker build or pull**
→ You need at least 100GB free. Check with `df -h /`.
→ Clean Docker cache: `docker system prune -af`

**"Out of memory" during generation**
→ Ensure no other GPU processes are running: `nvidia-smi`
→ The pipeline needs ~18GB VRAM peak during inference.

**Backend starts but health check fails**
→ Models may still be loading. Wait 2 minutes and retry.
→ Check logs: `docker compose logs -f`
→ Verify models exist: `ls -la models/base/`

**Backend unreachable from Confluence**
→ Verify HTTPS: `curl https://ai.yourcompany.com/health`
→ Verify firewall allows inbound port 443.
→ If behind corporate firewall, ensure Atlassian Cloud IPs can reach your server.

**Pipeline runs time out (502 Bad Gateway)**
→ Increase `proxy_read_timeout` in nginx to at least `1800s`.
→ Large specifications (5000+ words) can take 20-25 minutes to process.

**"Model file not found" on startup**
→ Run `./setup.sh` again — the model download may have been interrupted.
→ Verify: `ls -la models/base/Qwen2.5-14B-Instruct-GGUF/`

## Data Privacy

- All AI processing happens on **your** infrastructure
- The backend uses customer-provided Atlassian API credentials to read
  Confluence pages and create Jira issues — these credentials are stored
  in your `.env` file only, never transmitted externally
- No data passes through Spec2JIRA servers (there are none — this is
  fully self-hosted)
- Models run locally with no external API calls during inference
- See our full privacy policy at https://spec2jira.com/privacy
